/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mystafftracker;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Caleb Perumal
 */
public class EmployeeWorkerFunctionsTest {
    
    public EmployeeWorkerFunctionsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Testing Begun");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Testing complete");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

  
    @Test
    public void testClockIn() {
     
    }

@Test
    public void testClockOut() {
        
    }


    @Test
    public void testReport() {
        
    }
/*
    These JUnit tests were done to check the functionality of my methods
    in the EmployeeWorker class we testes the ffg methods:
    --EmployeeSearch
        */
  
    @Test
    public void testEmployeeSearch() {
    EmployeeWorkerFunctions ad = new EmployeeWorkerFunctions();
     ArrayList<EmployeeWorker> staff= new ArrayList<>();
    //***********************************************************************************
       //adding a admin first
       staff.add(new EmployeeWorker(1234,"1234","Caleb Perumal"));
    
       EmployeeWorker foundWorker = ad.employeeSearch(staff,1234);
        assertNotNull(foundWorker); // Expecting an Admin object to be found
        assertEquals(1234, foundWorker.getWorkerPassNum()); // Check if the found admin has the expected ID
    }
    
}

//This assignment is done