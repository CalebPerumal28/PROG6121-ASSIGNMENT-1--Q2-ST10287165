/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mystafftracker;

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Caleb Perumal
 */
public class AdminFunctionsTest {
    
    public AdminFunctionsTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Testing begun");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Testing complete");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
/*
    This is my unit tests of the admin functions
    it tests the following methods:
    --addStaffMem
    --DeleteEmploye
    --testingViewStaff (empty)
    --testingSearchFound
    --testing searchNotFound
    //All passed 100%
    */

    @Test
    public void testAddStaffMem() {
      AdminFunctions ad = new AdminFunctions();
      EmployeeWorkerFunctions mo = new EmployeeWorkerFunctions();
        Scanner scanner = new Scanner("123\n" + null + "Caleb Perumal");
        //adding employee
        ad.addStaffMem(scanner);
        int EmpSize = ad.EmployeeSize();
        System.out.println(EmpSize);
        assertEquals(1, EmpSize);
    }

    @Test
    public void testDeleteEmployee() {
       AdminFunctions ad = new AdminFunctions();
       ArrayList<Admin> adm = new ArrayList<>();
       EmployeeWorkerFunctions mo = new EmployeeWorkerFunctions();
       Scanner scanner = new Scanner("123\n" + null + "Caleb Perumal");
       //adding staff member
        ad.addStaffMem(scanner);
        int temp=ad.EmployeeSize();
        System.out.println("1st"+adm.size());//checking whether it is saving
        Scanner bo = new Scanner ("123\n+1");
          ad.deleteEmployee(bo);
           int tempAfterDelete= ad.EmployeeSize();
           assertEquals(temp-1, tempAfterDelete);

      
    
}
@Test
    public void testAdminSearchFound() {
 AdminFunctions ad = new AdminFunctions();
       ArrayList<Admin> adm = new ArrayList<>();
       //***********************************************************************************
       //adding a admin first
       adm.add(new Admin("1234","Caleb"));
     
    Admin foundAdmin = ad.AdminSearch(adm, "1234"); 
    assertNotNull(foundAdmin); // Expecting an Admin object to be found
    assertEquals("1234", foundAdmin.getIdPass()); // Check if the found admin has the expected ID
    }
    
@Test
    public void testEmptyViewStaff() {
    AdminFunctions ad = new AdminFunctions();
    ArrayList<Admin> adm = new ArrayList<>();
   EmployeeWorkerFunctions emp = new EmployeeWorkerFunctions();
   ArrayList<EmployeeWorker> staff= new ArrayList<>();
       //***********************************************************************************
//not required to add any staff...we want it to be empty
  EmployeeWorker ListEmp = ad.viewStaff();
  
  assertNull(ListEmp); // Expecting an Admin object to be found
//method returns null if no employees
   
    }
    @Test
    public void testAdminSearchNotFound() {
    AdminFunctions ad = new AdminFunctions();
    ArrayList<Admin> adm = new ArrayList<>();
   //***********************************************************************************
   //adding a admin first
   adm.add(new Admin("1234","Caleb"));
     
    Admin foundAdmin = ad.AdminSearch(adm, "1234");  //sendimgtest data to the method to be tested
  //assertNull(foundAdmin); // Expecting an Admin object to be found
      
    assertNotEquals("4321", foundAdmin.getIdPass()); // Check if the found admin has the expected ID
    }

}
//This assignment is done