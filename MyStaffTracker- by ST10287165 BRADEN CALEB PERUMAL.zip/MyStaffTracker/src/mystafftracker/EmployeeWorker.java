/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mystafftracker;

import java.util.ArrayList;

/**
 *
 * @author Caleb Perumal
 */
public class EmployeeWorker extends Admin {    // since admin has varibles name, we make the employee inherid the same.
private int workerPassNum;      // i declared a private variable to hold the employees id. 
private String staffname; // this will hold staff names 
ArrayList<StaffAttendance> emp = new ArrayList();  //declared a genric arraylist that essentially just creates a new employee that has its own attendence report when
//a new employee needed to be added or employee need to be deleted

    public EmployeeWorker(int workerPassNum, String idPass,String staffName) {  //this is my constructor, just replaces the setters 
        super(idPass,staffName);
        this.workerPassNum = workerPassNum;
          this.emp= new ArrayList<>();
          this.staffname=staffName;
    }

 
  

    public int getWorkerPassNum() {   //this is  my getters, utilized as it allows the variables to be accessed in other classes
        return workerPassNum;
    }
    
     public ArrayList<StaffAttendance> getAttendanceRecords() {
        return emp;    //getter of the generic array list
    }

    public String getStaffname() {
        return staffname;
    }

    public void addAttendanceRecord(StaffAttendance record) {
       emp.add(record);    //simples takes whatever recods and adde it to that specific employee attendence records
    }
    
}
//This assignment is done