/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mystafftracker;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import static mystafftracker.MyStaffTracker.kb;
import static mystafftracker.MyStaffTracker.staff;

/**
 *
 * @author Caleb Perumal
 */
public class EmployeeWorkerFunctions {
        
    public static void employeeMenu(){ //this menu is for the employees only
        System.out.println("Enter 1: Clock In\n"
                + "Enter 2--> Clock Out\n"
                + "Enter 3--> Genterate a report\n"
                +"Enter 4-->  Quit");
        int choice= kb.nextInt();
        while(choice<1 ||choice>4){
              System.out.println("Enter 1: Clock In\n"
                + "Enter 2--> Clock Out\n"
                + "Enter 3--> Genterate a report\n"
                +"Enter 4--> Quit");
            choice= kb.nextInt();    }
        
        switch (choice){
                    case 1: clockIn(); break;  //this invokes the clock in method to perform its function
                    case 2: clockOut(); break;  //this invokes the clock out method to perform its function
                    case 3: report(); break;  //this invokes the report in method to perform its function
                    case 4:System.out.println("You have quit the program");System.out.println("Thank you for using MyStaffTracker");System.exit(0); //terminates the program
                    
        }
                
    }
    
 //******************************************************************************************************************************
    //All our employee functions
     
    //this is the clock in method is it is responsible for prompting the employee for their id
    //after the id is fverfied, and if its valid, it will use the REAL LIVE TIME ad the clock in 
    //this will be saved to the specific employee ( IID PROVIDED_)  attendence record
     public static void clockIn(){      
      System.out.print("Enter Employee ID: ");
        int clockInId = kb.nextInt();
        EmployeeWorker stafMem = employeeSearch(staff ,clockInId); //sending the for which admin it is for and their id ...going in for a search 
         if (stafMem!= null) {
            int indexOfPrevious = stafMem.getAttendanceRecords().size() - 1;   //goes back to the previouis index to ensure they clocked out for a previouss clock in before clocking in again
                if (indexOfPrevious >= 0 && stafMem.getAttendanceRecords().get(indexOfPrevious).getClockOutTime() == null) {
                        System.out.println("Clock out for the previous clock in first before clocking in again.");
                             } else {
                                        LocalDateTime clockInTime = LocalDateTime.now();
                                        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  //formats our date and time
                                        String format = clockInTime.format(fmt);  //formatting our clock in time to the format stipulated above

            System.out.println("Employee successfully clocked in at " + format);
            stafMem.addAttendanceRecord(new StaffAttendance(clockInTime, null));   //save the clock in time to the that employee (id provided) attendence record
        }
    } else {
        System.out.println("Employee not found.");  //if id provided is not valid, then it will let user know 
    }
}     
        //this is the clock in method is it is responsible for prompting the employee for their id
    //after the id is fverfied, and if its valid, it will use the REAL LIVE TIME ad the clock in 
    //this will be saved to the specific employee ( IID PROVIDED_)  attendence record
     
     public static void clockOut(){
         
          System.out.print("Enter Employee ID: ");
               int clockOutId = kb.nextInt();
               EmployeeWorker stafMem = employeeSearch(staff,clockOutId); //sending the for which admin it is for and their id ...going in for a search 
                if (stafMem!= null) { //this is checking if there was a clock in time before clockout 
//after finding verfying the employee, he is given a menu
int indexOfPrevious= stafMem.getAttendanceRecords().size()-1;   //goes back to the previous index to see wheter ther was a clcok in in order for there top be a clock out
        if (  stafMem.getAttendanceRecords().size()!=0) {
                      LocalDateTime clockOutTime = LocalDateTime.now();
                      DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                      String format  = clockOutTime.format(fmt);
                      System.out.println("Employee successfully clocked out at "+format);
                   
                      stafMem.getAttendanceRecords().get( indexOfPrevious).setClockOutTime(clockOutTime); //this lin is simply just adding the clock out time to the generic array list. sice its adding it will takke to
                //a new index/ create a new object. To put the clockout time with the correct clockIn time we need to go to the previous index. We simply -1
                    } else{
                System.out.println("Must clock in before clocking out");
            }
                  } else {
                    //after finding verfying the admin, he was not there.
                        System.out.println("Employee not found.");
                    }
     }
     
     // this method is responsible for displaying the attendece report of the employye baed on their id 
     //it will display the attendence report for the employee id provided 
     
     public static void report(){
         if (staff.size()==0) {
             System.out.println("There are no employees");
         }
         if (staff.size()>0) {
                 System.out.print("Enter Employee ID: ");
                 int employeeID = kb.nextInt();
                 EmployeeWorker stafMem = employeeSearch(staff, employeeID); //sending the for which admin it is for and their id ...going in for a search 
       int numDaysWrked = 0;
      int totalHrsWorked = 0;
      int totalMinutesWorked=0;
            if (stafMem!= null) { //after finding verfying the employee, he is given a menu
                  ArrayList< StaffAttendance> Attend = stafMem.getAttendanceRecords();   
      
                     for (StaffAttendance StaffTime : Attend) {
                               if (StaffTime.getClockOutTime() != null) {
                                numDaysWrked ++;   //adding one day if they clocked out
                                LocalDateTime clockInTime = StaffTime.getClockInTime();  //retrieving the clocked in times 
                                LocalDateTime clockOutTime = StaffTime.getClockOutTime();//retrieving the clock out times 
                                Duration TimeWrked =  Duration.between(clockInTime,clockOutTime); //this i function was discovered through a simple google search and simply determines the hours worked
                                 int tempHours = (int) TimeWrked.toHours();
                                int tempMin=(int) TimeWrked.toMinutes();
                                   //  int tempCalcMin= (tempHours*60)-tempMin;
                                 totalHrsWorked += tempHours;       //incrementing the hours that the user works
                                 totalMinutesWorked+= tempMin;    

                                            }
                                        }
                                    } else {
                                    //after finding verfying the admin, he was not there.
                                        System.out.println("Employee not found.");
                                    }   
                System.out.println("-----------------------------------------------------------------------------");
                System.out.println("Attendance Report for Employee ID: "+ stafMem.getWorkerPassNum());
                System.out.println("");
                System.out.println("\nEmployee ID: " + stafMem.getWorkerPassNum());
        System.out.println("Total Days Worked: " + numDaysWrked);
     if (totalMinutesWorked<10) {
              System.out.println("Total time worked: "+totalHrsWorked+"H:"+"0"+totalMinutesWorked +"M" );
         }else{
          System.out.println("Total time worked: "+totalHrsWorked+"H:"+totalMinutesWorked +"M" );
     }
     
         System.out.println("------------------------------------------------------------------------------------");

         
         }
     }
     
     //this method simply just verifies the employee id by simply  checking the EmployeeWorker arraylist where all the different employees  are stored
public static EmployeeWorker employeeSearch (ArrayList<EmployeeWorker> worker, int empId) {
        for (EmployeeWorker wrker : worker) {
           int temp = wrker.getWorkerPassNum(); //holding the id in a temp var
                if (temp==empId){
                  return wrker ;
                  }
        }
        return null;
    }


}
//This assignment is done