/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mystafftracker;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Caleb Perumal
 */
public class MyStaffTracker {
final static Scanner kb= new Scanner (System.in); 
static ArrayList<EmployeeWorker> staff= new ArrayList<>();   //cfeated a array list of the all the objects in the EmployeeWorker class so that when a new employee is added it will increas this array list by 1 and that employuee will have their own attendence records
static ArrayList<Admin> adm = new ArrayList<>();    //created an generic array list of the admin to  hold admin in there 
    /**
     * @param args the command line arguments
     */
    /*
    //this is our main
    //the functions of my program include :
    *******************************************************************************************************************
    --> admin access
        -- access via pin
        -- add new employee'
        -- enters an employee id to generate report
        -- this is useful for the  finance department who will utilize this information to correctly pay the staff 
        --  they can also delete an employee by using their id
    ********************************************************************************************************************
    --> Employee access\
        -- access via an employee  id
        -- can clock in 
        -- can clock out
        --can generate a report for themselves
    ********************************************************************************************************************   
    */
    public static void main(String[] args) {
          
            
     System.out.println("*******************************************");  
        System.out.println("            MyStaffTracker ");
              System.out.println("------------------------------------------");
         System.out.println("  MADE POSSIBLE BY CALS SOFTWARE INC");
        System.out.println("               EST 2023");
         System.out.println("------------------------------------------");
          System.out.println("*******************************************");  
          
          System.out.println(" "); 
          System.out.println(" ");
      AdminFunctions mo = new AdminFunctions(); //instaniating the Admin class to access its methods 
          mo.MainMenu();  //invoking the main menu which is located in the Admion class , this line of code is the main part as it drags the rest of the function in, i
          //without this line their would be no staff tracking  program 

}//end of main
   
}
/*
References:
https://youtu.be/pTAda7qU4LY?si=UCsZgYHmEiKugCkm
https://youtu.be/NbYgm0r7u6o?si=8N_C-Hfw5YsXz3cH
https://youtu.be/fLwIScUeHE4?si=n-iKH-ixHpU2d8AW
https://youtu.be/kGLLtMIamuQ?si=EA7GCe0r-w-yvK5U
https://youtu.be/xk4_1vDrzzo?si=uvYwJfQh-4TeNMvn
https://www.informit.com/articles/article.aspx?p=1021579&seqNum=3'
https://stackoverflow.com/questions/21994005/generic-class-with-generic-arraylist
https://stackoverflow.com/questions/3990093/java-inheritance
Java Programming Joyce Farrell
CODE WORKING 100%
*/