/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mystafftracker;

import java.time.LocalDateTime;

/**
 *
 * @author Caleb Perumal
 */
public class StaffAttendance {
    private LocalDateTime clockInTime;      //declaring private varuiable for the clock in time , this varibale cannot be accessed beyon this class 
    private LocalDateTime clockOutTime;   //declaring private varuiable for the clock out time , this varibale cannot be accessed beyon this class 

    public StaffAttendance(LocalDateTime clockInTime, LocalDateTime clockOutTime) {
        this.clockInTime = clockInTime;
        this.clockOutTime = clockOutTime;
    }  //this is our constructor, its replaces the setters 

    public void setClockOutTime(LocalDateTime clockOutTime) {
        this.clockOutTime = clockOutTime;   //this is out setter
    }  

    public LocalDateTime getClockInTime() {
        return clockInTime;
    }   //this is out getters, this allows for the vales to be accessed beyon this class

    public LocalDateTime getClockOutTime() {
        return clockOutTime;   //this is out getters, this allows for the vales to be accessed beyon this class
    }
    
    
}
//This assignment is done