/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mystafftracker;

import java.util.ArrayList;
import java.util.Scanner;
import static mystafftracker.MyStaffTracker.adm;
import static mystafftracker.MyStaffTracker.kb;
import static mystafftracker.MyStaffTracker.staff;

/**
 *
 * @author Caleb Perumal
 */
public class AdminFunctions {
 public static void addAdmin(){
              if (adm.size()==0){
                System.out.println("There are no Admins");
                System.out.println("Do you want to add an admin? \n"
                        + "Enter 1--> Yes\n"
                        + "Enter 2--> No\n"
                        + "Enter 3 --> Quit");
                int userEnter = kb.nextInt();
                kb.nextLine();
                while (userEnter<1||userEnter>5){
                      System.out.println("Do you want to add an admin? \n"
                        + "Enter 1--> Yes\n"
                        + "Enter 2--> No\n"
                        + "Enter 3 --> Quit");
                userEnter = kb.nextInt();
                kb.nextLine();
                }
                switch(userEnter){
                    case 1: admin(); break;     
                    case 2: MainMenu();break;
                            case 3 :System.out.println("You have quit the program");System.out.println("Thank you for using MyStaffTracker");System.exit(0);
  
                            }
            }else {
                 System.out.println("Enter your admin pin number");
            String passPin = kb.next();
       Admin ad = AdminSearch(adm,passPin); //sending the for which admin it is for and their id ...going in for a search 
                if (ad!= null) { //after finding verfying the admin, he is given a menu
                    System.out.println("Welcome back "+ad.getStaffName());
                    System.out.println("");
                        adminMenu();
                    } else {
                    //after finding verfying the admin, he was not there.
                        System.out.println("Admin not found.");
                    }
                 
          //all done
          }
    }         
    
     //******************************************************************************************************************************
 
 //This method is for new admin to enter thier details 
 public static void admin(){
       
       
        String userA= null;
      
     boolean flag = true;
    while (flag) {
            System.out.println("Enter your user name that contains alphabets only and is WITHOUT any special characters *spaces allowed*");
            userA = kb.nextLine();
                    if (!userA.isEmpty() && userA.matches("^[a-zA-Z\\s]+$")) //this is checking whetther the username is empty or not and if it cnotains only allphebets and also allows for spaces bhy adding \\\s
                    {
                      flag=false;
                        break; //by using the break, we are terminating the loop if the username is not emply and if it contains alphebets only 
                    } else {
                        System.out.println("This username does not meet the requirements, ensure that username contains alphabets ONLY");
                    }
    } //end of while
     String pinn =null;
     boolean flaging = true;
 while (flaging) {
    System.out.println("Enter your 4 digit PIN");
    pinn = kb.nextLine();
                    if (pinn.isEmpty() || pinn.length() != 4 || !pinn.matches("[0-9]+")) { //checking if the pin meets the desired requirements \
                            System.out.println("This PIN does not meet the requirements. Please ensure that the PIN contains exactly 4 digits.");
                        } else {
                            flaging = false;
                            break;
                        }
}
 adm.add(new Admin(pinn,userA)); //creating a new admin object with that that has their name and passId
     

        System.out.println("You have being successfully added as an admin");
        //all done
        
    }
  //******************************************************************************************************************************
 
 //******************************************************************************************************************************
 //this method just verfies the admins pin
 public static Admin AdminSearch(ArrayList<Admin> administrators, String idd) {
        for (Admin admin : administrators) {
         String temp = admin.getIdPass();  //holding the id in a temp var
                if (temp.equals(idd)){
                      return admin;
                  }
        }//end of for each loop
        return null;
    }

 //all done

 // thsi method is the main menu 
    public static void MainMenu(){
        boolean flag =true;
        while (true){
            System.out.println("Enter 1--> Admin\nEnter 2--> Employee\nEnter 3--> Quit");
            int choice= kb.nextInt();
                     switch(choice){
                    
                      case 1: addAdmin();flag=true;   break; 
                      case 2:  if (staff.size()==0) { 
                                                System.out.println("There are no employees");
                                                System.out.println("You have to have administrative access to add an employee");
                                        }else{
                                                 EmployeeWorkerFunctions mo = new EmployeeWorkerFunctions();
                                                  mo.employeeMenu();
                                                 }flag=true; break;  
                      case 3: System.out.println("You have quit the program");System.out.println("Thank you for using MyStaffTracker");System.exit(0);//terminates program
        }//end of method
                } //end of while
    }
   
    
    //this is the admin menu and promts the admin with wat functions they can do
     public static void adminMenu(){
            boolean flag =true; 
                  while(true){ //continously promts admin until they exit the admin access and return to the main menu
                        System.out.println("Enter 1--> Add new staff member\n"
                                + "Enter 2--> Delete staff member\n"
                                + "Enter 3--> Genterate attendance report of staff member\n"
                                +"Enter 4--> Generate staff list\n"
                                 +"Enter 5--> Return back to main menu\n"      
                                + "Enter 6--> Quit");

                        int userEntry= kb.nextInt();
                        while(userEntry<1 ||userEntry>6){
                                System.out.println("Enter 1--> Add new staff member\n"
                                + "Enter 2--> Delete staff member\n"
                                + "Enter 3--> Genterate attendance report of staff member\n"
                                +"Enter 4--> Generate staff list\n"
                                +"Enter 5--> Return back to main menu\n"      
                                + "Enter 6--> Quit");

                 userEntry= kb.nextInt();
                        }

                        switch(userEntry){
                            case 1:addStaffMem(kb);break;
                            case 2:   if (staff.size()==0) {
                             System.out.println("There are no employees");
                             } else{deleteEmployee(kb);} break;
                            case 3: EmployeeWorkerFunctions mo = new EmployeeWorkerFunctions(); mo.report(); break;
                            case 4: viewStaff(); break;
                            case 5:System.out.println("Successfully Logged Out");MainMenu();break;
                            case 6:flag=false;
                            System.out.println("You have quit the program");System.out.println("Thank you for using MyStaffTracker"); 
                            System.exit(0);
                            break;

                        }

       }
    }
    
     // this metod is resposible for adding a new employee
    public static void addStaffMem(Scanner kb){
         System.out.print("Enter Employee ID: ");
          int staffId = kb.nextInt();
          kb.nextLine();
                            
           System.out.print("Enter staff members name: ");
           String name = kb.nextLine();
                  
          staff.add(new EmployeeWorker(staffId ,null,name)); //creating a new employee copject with that id
          System.out.println("Employee successfully added");
                    
    }

    //this method is  responsible for deleting a employee by the admin proividing the employees emoplyee id number
       public static void deleteEmployee(Scanner kb){
         System.out.println("Enter Employee Id to delete");
         int deleteId = kb.nextInt();
         EmployeeWorkerFunctions mo = new EmployeeWorkerFunctions();
          
        EmployeeWorker stafMem = mo.employeeSearch(staff,deleteId); //sending the for which admin it is for and their id ...going in for a search 
                if (stafMem!= null) {
                     System.out.println("Enter 1-->Confirm Detele\nEnter 2--> Cancel Delete");
                     int  delChoice= kb.nextInt();//after finding verfying the employee, he is given a menu
                switch(delChoice){
                 case 1:   if (stafMem!= null) { //after finding verfying the employee, he is given a menu
                          staff.remove(stafMem);
                          System.out.println(stafMem.getStaffname()+" (ID:"+stafMem.getWorkerPassNum()+"), has been deleted");
                                             }    break;
                 case 2: System.out.println("Detele request canceled"); break;
                            }
                                    }else {
                    System.out.println("Employee not found");
                }
         
                 
     }
       
       //this methos is responsib;e displaying (to thhe admin)a list of all the employees along with their employee id number
        public static EmployeeWorker viewStaff(){
         EmployeeWorker returnVal=null;
         if (staff.size()!=0) {
                
                System.out.println("Employee List:");
                System.out.println("----------------------------------------------------------");
                        for (EmployeeWorker emp : staff) {
                            System.out.println("Employee name: "+ emp.getStaffname());
                            System.out.println("Employee ID: "+ emp.getWorkerPassNum());
                            System.out.println("***************************************************");
                            returnVal= emp;
                        }
            }else{
                  System.out.println("Employee List:");
                  System.out.println("<<<<<empty>>>>>");
                   returnVal=null;
                        }
            
        return returnVal;
        }
        
        // this method is responsible for quiting returning the bumber of employees
public int EmployeeSize(){ 
return staff.size();

}

}//end of class
//This assignment is done