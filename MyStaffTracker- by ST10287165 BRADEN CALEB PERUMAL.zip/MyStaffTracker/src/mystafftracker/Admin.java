/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mystafftracker;

import java.util.logging.Logger;

/**
 *
 * @author Caleb Perumal
 */
public class Admin {
   private String idPass;   //this is a private variable that is declred to hold the admins oin in this class
  private String staffName;    //this is a private variable that is declred to hold the admins name in this class

    public Admin(String idPass,String staffName){  //constructor replaces the setters 
        this.idPass = idPass;
this.staffName= staffName;
               
    }
//these aere our getters and is used for the vairbales to be accessed in other classes
    public String getIdPass() {
        return idPass;
    }

    public String getStaffName() {
        return staffName;
    }
}


//This assignment is done